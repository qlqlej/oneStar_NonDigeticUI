﻿using UnityEngine;
using System.Collections;

public class resultscene : MonoBehaviour {

    private float nowtime;
    public GUIText SCORE, KM, COIN,touch;
    public static float score,km,coin;
	// Use this for initialization
	void Start () {
        nowtime = 0;
        touch.enabled = false;
        touch.fontSize=COIN.fontSize=SCORE.fontSize = KM.fontSize = Mathf.RoundToInt(Camera.main.pixelHeight / 10f);
	}
	
	// Update is called once per frame
	void Update () {
        coin = (score / 100) + (km/10);
        nowtime+=Time.smoothDeltaTime;
        if (nowtime>1)
        {
            touch.enabled = true;
        }
        if (Input.GetKeyDown("mouse 0") && nowtime>1)
        {
            Application.LoadLevel("menuscene");
        }
	}

    void OnGUI()
    {
        SCORE.text = "" + (int)score;
        KM.text = "" + (int)km;
        COIN.text = "" + (int)coin;
    }
}
