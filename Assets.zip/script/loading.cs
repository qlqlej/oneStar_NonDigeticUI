﻿using UnityEngine;
using System.Collections;

public class loading : MonoBehaviour {
    public Texture2D whitetexture;
    private float alphablend;
    private bool fade;
    private Material m;
    private float frametime,nowtime,nowframe;
	// Use this for initialization
	void Start () {
        fade = true;
        alphablend = 1;
        m = gameObject.GetComponent<Renderer>().material;
        frametime = 0.1f;
        nowtime = 0.0f;
        nowframe = 4;
	}
	
	// Update is called once per frame
	void Update () {
        nowtime += Time.smoothDeltaTime;
        if (alphablend <= 0.0f && fade)
        {
            fade = false;
            alphablend = -5;
        }
        if (alphablend >= 1.1f)
        {
            if (totalmanager.nextscene==1)
            {
                Application.LoadLevel("gamescene");
            }
            else if (totalmanager.nextscene == 0)
            {
                Application.LoadLevel("menuscene");
            }
        }
        if (nowtime>frametime)
        {
            nowframe--;
            if (nowframe<0)
            {
                nowframe = 4;
            }
            Vector2 v = m.GetTextureOffset("_MainTex");
            v.y = nowframe * 0.2f;
            m.SetTextureOffset("_MainTex", v);
            nowtime = 0.0f;
        }     
	}

    void OnGUI()
    {
        if (fade)
        {
            alphablend -= Mathf.Clamp01(Time.smoothDeltaTime / 1.0f);
            GUI.color = new Color(0, 0, 0, alphablend);
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), whitetexture);
        }
        else
        {
            alphablend += Mathf.Clamp01(Time.smoothDeltaTime / 1.0f);
            GUI.color = new Color(0, 0, 0, alphablend);
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), whitetexture);
        }
    }
}
